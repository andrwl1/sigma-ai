from pathlib import Path
import pandas as pd
from datetime import datetime

DATA = Path("outputs/data/subjectivity_log.csv")
REPORTS = Path("outputs/reports"); REPORTS.mkdir(parents=True, exist_ok=True)
out_txt = REPORTS / "status.txt"

def generate_status(save: bool = True) -> str:
    """Формирует текстовый статус (total/сегодня/базовый шаг) и добавляет краткие метрики."""
    if not DATA.exists():
        return "Нет данных."

    df = pd.read_csv(DATA)
    df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
    df["Date"] = df["Timestamp"].dt.date

    # Суммарно по осям
    total = df["Axis"].value_counts().sort_index()

    # За сегодня
    today = datetime.now().date()
    today_df = df[df["Date"] == today]
    today_counts = today_df["Axis"].value_counts().sort_index()
    baseline_ok = len(today_df) >= 1

    lines = [f"DATE: {today}", "TOTAL (все дни):"]
    for ax, n in total.items():
        lines.append(f"  - {ax}: {n}")

    lines.append("TODAY:")
    if today_counts.empty:
        lines.append("  - записей нет")
    else:
        for ax, n in today_counts.items():
            lines.append(f"  - {ax}: {n}")

    lines.append(f"Базовый шаг засчитан: {'ДА' if baseline_ok else 'НЕТ'}")

    # --- КОРОТКИЕ МЕТРИКИ ---
    try:
        from src.metrics import run as run_metrics
        m = run_metrics()
        if m:
            lines.append("\nMETRICS:")
            lines.append(f"  - streak_days: {m['streak']}")
            lines.append(f"  - balance_H_norm: {m['balance_H_norm']:.3f}")
            lines.append(f"  - G_today: {m['G_today']}")
    except Exception as e:
        lines.append(f"\nMETRICS: skipped ({e})")

    # Сборка текста после добавления метрик
    text = "\n".join(lines)
    if save:
        out_txt.write_text(text, encoding="utf-8")

