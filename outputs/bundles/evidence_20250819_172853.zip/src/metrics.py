from pathlib import Path
from datetime import datetime
import math
import pandas as pd

LOG = Path("outputs/data/subjectivity_log.csv")
OUT_DIR = Path("outputs/reports"); OUT_DIR.mkdir(parents=True, exist_ok=True)
METRICS_CSV = OUT_DIR / "metrics.csv"

AXES = ["субъектность", "воля", "логика", "этика", "границы", "рефлексия"]

def load_df() -> pd.DataFrame:
    df = pd.read_csv(LOG)
    df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
    df["Date"] = df["Timestamp"].dt.date
    return df

def compute_metrics(df: pd.DataFrame) -> dict:
    # M1: суммарно по осям
    total_by_axis = df["Axis"].value_counts().reindex(AXES).fillna(0).astype(int)

    # По дням/осям
    pivot = (df.pivot_table(index="Date", columns="Axis", values="Timestamp", aggfunc="count")
               .reindex(columns=AXES).fillna(0).astype(int))
    pivot = pivot.sort_index()

    # M2: скорость (7-дневное среднее)
    rolling7 = pivot.rolling(7, min_periods=1).mean()

    # M3: текущая серия дней с ≥1 записью
    day_total = pivot.sum(axis=1)
    streak = 0
    for v in reversed(day_total.tolist()):
        if v >= 1: streak += 1
        else: break

    # M4: баланс (энтропия)
    S = total_by_axis.sum()
    if S == 0:
        H_norm = 0.0
    else:
        p = (total_by_axis / S).replace(0, float("nan"))
        H = - (p * p.apply(lambda x: math.log(x))).sum(skipna=True)
        k = (total_by_axis > 0).sum()
        H_norm = float(H / math.log(k)) if k > 1 else 0.0

    # M5: индекс роста дня (сегодня)
    today = datetime.now().date()
    today_cnt = pivot.loc[pivot.index == today].sum(axis=1)
    G_today = int(today_cnt.iloc[0]) if not today_cnt.empty else 0

    return {
        "total_by_axis": total_by_axis,
        "pivot": pivot,
        "rolling7": rolling7,
        "streak": streak,
        "balance_H_norm": H_norm,
        "G_today": G_today,
    }

def save_metrics_csv(pivot: pd.DataFrame, rolling7: pd.DataFrame):
    # сохраняем оба — помечая тип ряда
    df1 = pivot.copy();     df1["series"] = "daily"
    df2 = rolling7.copy();  df2["series"] = "rolling7"
    out = pd.concat([df1, df2]).reset_index().rename(columns={"Date":"date"})
    out.to_csv(METRICS_CSV, index=False, encoding="utf-8")

def run():
    if not LOG.exists():
        print("Нет лога — метрики пропущены.")
        return
    df = load_df()
    m = compute_metrics(df)
    save_metrics_csv(m["pivot"], m["rolling7"])
    print("metrics.csv сохранён:", METRICS_CSV)
    print("streak:", m["streak"], "| balance_H_norm:", round(m["balance_H_norm"], 3), "| G_today:", m["G_today"])
    return m

if __name__ == "__main__":
    run()

