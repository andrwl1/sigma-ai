[2025-10-23] SB-1 baseline confirmed — GIT:812c629e399919eaf18c47e7547cf072b87d5b6c — tag: stable_t3000_sb1
[2025-10-23] LEGAL_PROOF_SET1 — SHA256:e137399344acafb586cfb692955066eae416606b911c6dd02e4cff8b652c44df — contents: affidavit+manifest+proof
[2025-10-23 17:06:45] T3000 Comparison A/B — ab_diff.csv:4837e969904da8d77e9ce138d77e3b972dbf7717a43058686a3a1c96f39dd1ee ab_report.md:65e609dae685290afa9a600fa48131351efa92391c49201905775efcda88e1c2 (llama3.1:8b vs gpt-4o-mini)
