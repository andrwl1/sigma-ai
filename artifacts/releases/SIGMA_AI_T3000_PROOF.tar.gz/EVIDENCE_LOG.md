[2025-10-23] SB-1 baseline confirmed — GIT:812c629e399919eaf18c47e7547cf072b87d5b6c — tag: stable_t3000_sb1
